#include "FunctionCalculator.h"

/// <summary>
/// a project to test different collisions :)
/// </summary>
/// <returns></returns>

int main() {

	FunctionCalculator a;
	return 0;
}