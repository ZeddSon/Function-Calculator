#ifndef MACROS_H
#define MACROS_H



const char MIX= 'M';
const char POLY = 'P';
const char SIN= 'S';
const char NATURALLOG = 'N';
const char FUNCTIONLOG = 'L';

#define MAX_NAME_LEN 1000
#endif